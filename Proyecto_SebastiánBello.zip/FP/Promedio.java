public interface Promedio{
  public double promes();
}
