public class JMenuItemAdministrador implements java.awt.event.ActionListener{
  MenuDirector md;

    public JMenuItemAdministrador(MenuDirector _md){
      md = _md;
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {
      try{
        VentanaAdministrador va = new VentanaAdministrador("Universidad Veracruzana - Administrador");
        md.dispose();
       }catch(java.lang.NullPointerException z){
         System.out.println(z);
       }
     }
}
