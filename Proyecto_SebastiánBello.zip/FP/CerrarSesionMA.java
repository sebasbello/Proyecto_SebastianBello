public class CerrarSesionMA implements java.awt.event.ActionListener{
  MenuAdministrador md;

    public CerrarSesionMA(MenuAdministrador _md){
      md = _md;
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {
      try{
        Ventana v = new Ventana("Universidad Veracruzana");
          md.dispose();
       }catch(java.lang.NullPointerException z){
         System.out.println(z);
       }
     }
}
