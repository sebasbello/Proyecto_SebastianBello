public class CerrarSesionP implements java.awt.event.ActionListener{
  VentanaProfesor md;

    public CerrarSesionP(VentanaProfesor _md){
      md = _md;
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {
      try{
        Ventana v = new Ventana("Universidad Veracruzana");
          md.dispose();
       }catch(java.lang.NullPointerException z){
         System.out.println(z);
       }
     }
}
