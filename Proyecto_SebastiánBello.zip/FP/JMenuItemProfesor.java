public class JMenuItemProfesor implements java.awt.event.ActionListener{
  MenuDirector md;

    public JMenuItemProfesor(MenuDirector _md){
      md = _md;
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {
      try{
        VentanaProfesor vp = new VentanaProfesor("Universidad Veracruzana - Profesor");
        md.dispose();
       }catch(java.lang.NullPointerException z){
         System.out.println(z);
       }
     }
}
