import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import java.awt.Color;

public class Ventana extends JFrame{
  // Componentes.
  JFrame f;
  JButton e;
  ImageIcon ii;
  JLabel u,c;
  JTextField jt;
  JPasswordField jp;

    public Ventana(String _titulo){
      super(_titulo);
      // Definir la posición y la dimensión de la ventana.
      this.setBounds(50,50,600,600);
      this.setLayout(null);
      this.getContentPane().setBackground(Color.WHITE);

      // Logo.
      ii = new ImageIcon("imagen/logo.png");
      this.setIconImage(ii.getImage());

      // public void setBounds(int x,int y,int width,int height)

      // JButton. Se utilizan después del inicio de sesión.
      e = new JButton("Entrar");
      e.setBounds(350,135,120,60);
      e.setHorizontalAlignment(0);
      GestionBoton gb = new GestionBoton(this);
      e.addActionListener(gb);

      // JLabel.
      u = new JLabel("Usuario");
      u.setBounds(80,120,100,40);

      c = new JLabel("Clave");
      c.setBounds(80,170,100,40);

      // JTextField.
      jt = new JTextField("",20);
      jt.setBounds(200,120,100,40);

      jp = new JPasswordField("",20);
      jp.setBounds(200,170,100,40);

      this.add(u);
      this.add(c);
      this.add(jt);
      this.add(jp);
      this.add(e);

      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.setVisible(true);
    }
}
