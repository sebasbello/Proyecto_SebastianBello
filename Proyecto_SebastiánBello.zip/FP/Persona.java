public class Persona{
  String nombre;
  int edad;

  // Constructor por defecto.
  public Persona(){

  }

  // Constructor.
  public Persona(String _nombre, int _edad){
    this.nombre = _nombre;
    this.edad = _edad;
  }

  // Setters.
  public void setNombre(String _nombre){
    this.nombre = _nombre;
  }

  public void setEdad(int _edad){
    this.edad = _edad;
  }

  // Getters.
  public String getNombre(){
    return nombre;
  }

  public int getEdad(){
    return edad;
  }

}
