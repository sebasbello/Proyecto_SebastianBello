public class TransicionA implements java.awt.event.ActionListener{
  VentanaProfesor md;

    public TransicionA(VentanaProfesor _md){
      md = _md;
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {
      try{
        VentanaAdministrador v = new VentanaAdministrador("Universidad Veracruzana - Administrador");
          md.dispose();
       }catch(java.lang.NullPointerException z){
         System.out.println(z);
       }
     }
}
