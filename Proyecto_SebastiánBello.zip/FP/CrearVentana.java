import java.awt.Frame;

public class CrearVentana{
    public static void main(String[] args){
      Ventana v = new Ventana("Universidad Veracruzana");
    }
}
