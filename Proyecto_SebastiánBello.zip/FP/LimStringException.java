public class LimStringException extends Exception{
    public LimStringException(String mensaje){
      super(mensaje);
    }
}
