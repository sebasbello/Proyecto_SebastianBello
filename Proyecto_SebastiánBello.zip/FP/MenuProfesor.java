import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.io.Writer;
import java.io.Reader;
import java.io.FileReader;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;

public class MenuProfesor extends JFrame{
  // Componentes.
  JFrame f;
  ImageIcon ii;
  JMenuBar b;
  JMenu i,e,v;
  JMenuItem s,cs,p,a,prof;
  JTextField nombre, matricula,posicion,ing,pros;
  JLabel no,ma,ed,pos,pr,promedio;
  JButton regis,eli,cam,grupoA,grupoB,promSemestre;
  MenuProfesor vp;
  ArrayList<Estudiante> estudiante = new ArrayList<>();
  ArrayList<Estudiante> estudianteA = new ArrayList<>();
  ArrayList<Estudiante> estudianteB = new ArrayList<>();
  ArrayList<Materia> materias = new ArrayList<>();
  int indice=0, itA=1, itB=1;
  double promB=0, promA=0, promGen=0;
  Calendar cal = new GregorianCalendar();
  String mensaje,mensaje1;

  public MenuProfesor(String _titulo){
    super(_titulo);
    // Definir la posición y la dimensión de la ventana.
    this.setBounds(50,50,600,600);
    this.setLayout(null);
    this.getContentPane().setBackground(Color.WHITE);

    // Logo.
    ii = new ImageIcon("imagen/logo.png");
    this.setIconImage(ii.getImage());

    // JMenuBar.
    b = new JMenuBar();

    // JMenu
    i = new JMenu("Inicio");
    b.add(i);

    // JMenuItem - Inicio
    cs = new JMenuItem("Cerrar sesion");
    i.add(cs);
    CerrarSesionMP cse = new CerrarSesionMP(this);
    cs.addActionListener(cse);

    s = new JMenuItem("Salir");
    i.add(s);
    s.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          System.exit(0);
        }
      }
    );
    setJMenuBar(b);

    // JTextField.
    nombre = new JTextField("",30);
    nombre.setBounds(150,120,100,30);
    this.add(nombre);

    matricula = new JTextField("",30);
    matricula.setBounds(150,150,100,30);
    this.add(matricula);

    ing = new JTextField("",30);
    ing.setBounds(150,180,100,30);
    this.add(ing);

    posicion = new JTextField("",30);
    posicion.setBounds(480,150,60,30);
    posicion.setHorizontalAlignment(0);
    this.add(posicion);

    pros = new JTextField("",30);
    pros.setBounds(150,210,100,30);
    this.add(pros);

    // JLabel.
    no = new JLabel("Clase");
    no.setBounds(60,120,80,30);
    this.add(no);

    ma = new JLabel("Matricula");
    ma.setBounds(60,150,80,30);
    this.add(ma);

    ed = new JLabel("Calificacion");
    ed.setBounds(60,180,80,30);
    this.add(ed);

    pr = new JLabel("Profesor");
    pr.setBounds(60,210,80,30);
    this.add(pr);

    pos = new JLabel("Posicion");
    pos.setBounds(420,150,60,30);
    pos.setHorizontalAlignment(0);
    this.add(pos);

    promedio = new JLabel("Semestre Promedio");
    promedio.setBounds(310,340,150,30);
    promedio.setHorizontalAlignment(0);
    this.add(promedio);


    // Botón Agregar.
    regis = new JButton("Registrar");
    regis.setBounds(300,120,120,30);
    regis.setHorizontalAlignment(0);
    this.add(regis);
    regis.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          try{
            Persona pr = new Estudiante();
            Materia mats = new Materia();

            if(matricula.getText().length()==8){
              ((Estudiante)pr).setMatri(matricula.getText());
                mats.setClase(nombre.getText());
                mats.setNota(Double.parseDouble(ing.getText()));
                mats.setProfesor(pros.getText());
                materias.add(mats);
              ((Estudiante)pr).setMaterias(materias);
              estudiante.add((Estudiante)pr);
            }else{
              throw new LimStringException("LimStringException");
            }

            File w = new File("Registro calificaciones.txt");
            if(!w.exists()){
              w.createNewFile();
              FileWriter fw = new FileWriter(w,true);
              PrintWriter pw = new PrintWriter(fw);
              pw.println("Actualizacion: " + cal.getTime());
              pw.println("\tDatos:");
              pw.println("\t"+estudiante);
              pw.close();
              fw.close();
              nombre.setText("");
              matricula.setText("");
              ing.setText("");
              JOptionPane.showMessageDialog(vp, new JLabel("Agregado", JLabel.CENTER));
            }else{
              w.createNewFile();
              FileWriter fw = new FileWriter(w,true);
              PrintWriter pw = new PrintWriter(fw);
              pw.println("Actualizacion: " + cal.getTime());
              pw.println("\tDatos:");
              pw.println("\t"+estudiante);
              pw.close();
              fw.close();
              nombre.setText("");
              matricula.setText("");
              ing.setText("");
              JOptionPane.showMessageDialog(vp, new JLabel("Agregado", JLabel.CENTER));
            }
          }catch(java.io.IOException a){
            System.out.println(a);
          }catch(java.lang.IndexOutOfBoundsException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Limite rebasado", JLabel.CENTER));
          }catch(LimStringException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Datos incorrectos", JLabel.CENTER));
          }
        }
      }
    );

    // Botón Cambio.
    cam = new JButton("Cambiar");
    cam.setBounds(300,150,120,30);
    cam.setHorizontalAlignment(0);
    this.add(cam);
    cam.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          try{
            if(((posicion.getText()) != "") && (Integer.parseInt(posicion.getText())<estudiante.size())){
              indice = Integer.parseInt(posicion.getText());
            }

            Persona pr = new Estudiante();
            if(matricula.getText().length()==8){
              pr.setNombre(nombre.getText());
              ((Estudiante)pr).setMatri(matricula.getText());
              ((Estudiante)pr).setIngreso(ing.getText());
              estudiante.set(indice,((Estudiante)pr));
            }else{
              throw new LimStringException("LimStringException");
            }

            File w = new File("Registro calificaciones.txt");
            if(!w.exists()){
              w.createNewFile();
              FileWriter fw = new FileWriter(w,true);
              PrintWriter pw = new PrintWriter(fw);
              pw.println("Actualizacion: " + cal.getTime());
              pw.println("\tDatos:");
              pw.println("\t"+estudiante);
              pw.close();
              fw.close();
              nombre.setText("");
              matricula.setText("");
              ing.setText("");
              posicion.setText("");
              JOptionPane.showMessageDialog(vp, new JLabel("Cambiado", JLabel.CENTER));
            }else{
              w.createNewFile();
              FileWriter fw = new FileWriter(w,true);
              PrintWriter pw = new PrintWriter(fw);
              pw.println("Actualizacion: " + cal.getTime());
              pw.println("\tDatos:");
              pw.println("\t"+estudiante);
              pw.close();
              fw.close();
              nombre.setText("");
              matricula.setText("");
              ing.setText("");
              posicion.setText("");
              JOptionPane.showMessageDialog(vp, new JLabel("Cambiado", JLabel.CENTER));
            }
          }catch(java.io.IOException a){
            System.out.println(a);
          }catch(java.lang.NumberFormatException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Campo vacio", JLabel.CENTER));
          }catch(java.lang.IndexOutOfBoundsException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Limite rebasado", JLabel.CENTER));
          }catch(LimStringException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Datos incorrectos", JLabel.CENTER));
          }
        }
      }
    );

    // Botón Eliminar.
    eli = new JButton("Eliminar");
    eli.setBounds(300,180,120,30);
    eli.setHorizontalAlignment(0);
    this.add(eli);
    eli.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          try{
            if(((posicion.getText()) != "") && (Integer.parseInt(posicion.getText())<estudiante.size())){
              indice = Integer.parseInt(posicion.getText());
            }

            estudiante.remove(indice);

            File w = new File("Registro calificaciones.txt");
            if(!w.exists()){
              w.createNewFile();
              FileWriter fw = new FileWriter(w,true);
              PrintWriter pw = new PrintWriter(fw);
              pw.println("Actualizacion: " + cal.getTime());
              pw.println("\tDatos:");
              pw.println("\t"+estudiante);
              pw.close();
              fw.close();
              matricula.setText("");
              ing.setText("");
              posicion.setText("");
              JOptionPane.showMessageDialog(vp, new JLabel("Eliminado", JLabel.CENTER));
            }else{
              w.createNewFile();
              FileWriter fw = new FileWriter(w,true);
              PrintWriter pw = new PrintWriter(fw);
              pw.println("Actualizacion: " + cal.getTime());
              pw.println("\tDatos:");
              pw.println("\t"+estudiante);
              pw.close();
              fw.close();
              matricula.setText("");
              ing.setText("");
              posicion.setText("");
              JOptionPane.showMessageDialog(vp, new JLabel("Eliminado", JLabel.CENTER));
            }
          }catch(java.io.IOException a){
            System.out.println(a);
          }catch(java.lang.NumberFormatException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Campo vacio", JLabel.CENTER));
          }catch(java.lang.IndexOutOfBoundsException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Limite rebasado", JLabel.CENTER));
          }
        }
      }
    );

    grupoA = new JButton("Promedio Grupo A");
    grupoA.setBounds(100,310,160,30);
    grupoA.setHorizontalAlignment(0);
    this.add(grupoA);
    grupoA.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          try{
            Persona pr = new Estudiante();
            Materia mats = new Materia();
            if(matricula.getText().length()==8){
              ((Estudiante)pr).setMatri(matricula.getText());
                mats.setClase(nombre.getText());
                mats.setNota(Double.parseDouble(ing.getText()));
                mats.setProfesor(pros.getText());
                materias.add(mats);
              ((Estudiante)pr).setMaterias(materias);
              estudianteA.add((Estudiante)pr);

              promA+=Double.parseDouble(ing.getText());
              itA+=1;
              mensaje1 = String.valueOf(promA/itA);

            }else{
              throw new LimStringException("LimStringException");
            }

            File w = new File("Registro grupo A.txt");
            if(!w.exists()){
              w.createNewFile();
              FileWriter fw = new FileWriter(w,true);
              PrintWriter pw = new PrintWriter(fw);
              pw.println("Actualizacion: " + cal.getTime());
              pw.println("\tDatos:");
              pw.println("\t"+estudianteA);
              pw.println("\t"+mensaje1);
              pw.close();
              fw.close();
              JOptionPane.showMessageDialog(vp, new JLabel("Estudiante grupo A", JLabel.CENTER));
            }else{
              w.createNewFile();
              FileWriter fw = new FileWriter(w,true);
              PrintWriter pw = new PrintWriter(fw);
              pw.println("Actualizacion: " + cal.getTime());
              pw.println("\tDatos:");
              pw.println("\t"+estudianteA);
              pw.println("\tPromedio general grupo A: "+mensaje1);
              pw.close();
              fw.close();
              JOptionPane.showMessageDialog(vp, new JLabel("Estudiante grupo A", JLabel.CENTER));
            }

          }catch(java.io.IOException a){
            System.out.println(a);
          }catch(java.lang.NumberFormatException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Campo vacio", JLabel.CENTER));
          }catch(java.lang.IndexOutOfBoundsException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Limite rebasado", JLabel.CENTER));
          }catch(LimStringException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Datos incorrectos", JLabel.CENTER));
          }
        }
      }
    );

    grupoB = new JButton("Promedio Grupo B");
    grupoB.setBounds(100,340,160,30);
    grupoB.setHorizontalAlignment(0);
    this.add(grupoB);
    grupoB.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          try{
            Persona pr = new Estudiante();
            Materia mats = new Materia();
            if(matricula.getText().length()==8){
              ((Estudiante)pr).setMatri(matricula.getText());
                mats.setClase(nombre.getText());
                mats.setNota(Double.parseDouble(ing.getText()));
                mats.setProfesor(pros.getText());
                materias.add(mats);
              ((Estudiante)pr).setMaterias(materias);
              estudianteB.add((Estudiante)pr);

              promB+=Double.parseDouble(ing.getText());
              itB+=1;
              mensaje = String.valueOf(promB/itB);

            }else{
              throw new LimStringException("LimStringException");
            }

            File w = new File("Registro grupo B.txt");
            if(!w.exists()){
              w.createNewFile();
              FileWriter fw = new FileWriter(w,true);
              PrintWriter pw = new PrintWriter(fw);
              pw.println("Actualizacion: " + cal.getTime());
              pw.println("\tDatos:");
              pw.println("\t"+estudianteB);
              pw.println("\t"+mensaje);
              pw.close();
              fw.close();
              JOptionPane.showMessageDialog(vp, new JLabel("Estudiante grupo B", JLabel.CENTER));
            }else{
              w.createNewFile();
              FileWriter fw = new FileWriter(w,true);
              PrintWriter pw = new PrintWriter(fw);
              pw.println("Actualizacion: " + cal.getTime());
              pw.println("\tDatos:");
              pw.println("\t"+estudianteB);
              pw.println("\tPromedio general grupo B: "+mensaje);
              pw.close();
              fw.close();
              JOptionPane.showMessageDialog(vp, new JLabel("Estudiante grupo B", JLabel.CENTER));
            }

          }catch(java.io.IOException a){
            System.out.println(a);
          }catch(java.lang.NumberFormatException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Campo vacio", JLabel.CENTER));
          }catch(java.lang.IndexOutOfBoundsException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Limite rebasado", JLabel.CENTER));
          }catch(LimStringException a){
            JOptionPane.showMessageDialog(vp, new JLabel("Datos incorrectos", JLabel.CENTER));
          }
        }
      }
    );

    promSemestre = new JButton("Semestre Promedio");
    promSemestre.setBounds(100,370,160,30);
    promSemestre.setHorizontalAlignment(0);
    this.add(promSemestre);
    promSemestre.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
            /*promGen=(promA+promB)/(itA+itB);
            promedio.setText(String.valueOf(promGen));*/
            promedio.setText(String.valueOf(promes(itA,itB,promA,promB)));
        }
      }
    );

    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setVisible(true);
  }

  public double promes(int a, int b, double x, double y){
    double prome;
    if(a>0 && b>0){
      prome = (x+y)/(a+b);
      return prome;
    }else{
      prome = 0;
      return prome;
    }
  }

}
