import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MenuDirector extends JFrame{
  // Componentes.
  JFrame f;
  ImageIcon ii;
  JMenuBar b;
  JMenu i,e;
  JMenuItem s,cs,p,a;

    public MenuDirector(String _titulo){
      super(_titulo);
      // Definir la posición y la dimensión de la ventana.
      this.setBounds(50,50,600,600);
      this.setLayout(null);
      this.getContentPane().setBackground(Color.WHITE);

      // Logo.
      ii = new ImageIcon("imagen/logo.png");
      this.setIconImage(ii.getImage());

      // JMenuBar.
      b = new JMenuBar();

      // JMenu
      i = new JMenu("Inicio");
      b.add(i);

      e = new JMenu("Editar");
      b.add(e);

      // JMenuItem - Inicio
      cs = new JMenuItem("Cerrar sesion");
      i.add(cs);
      CerrarSesionD cse = new CerrarSesionD(this);
      cs.addActionListener(cse);

      s = new JMenuItem("Salir");
      i.add(s);
      s.addActionListener(
        new ActionListener(){
          public void actionPerformed(ActionEvent e){
            System.exit(0);
          }
        }
      );


      // JMenuItem - Editar
      a = new JMenuItem("Administrador");
      e.add(a);
      JMenuItemAdministrador ipa = new JMenuItemAdministrador(this);
      a.addActionListener(ipa);

      p = new JMenuItem("Profesor");
      e.add(p);
      JMenuItemProfesor ipp = new JMenuItemProfesor(this);
      p.addActionListener(ipp);
      setJMenuBar(b);


      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.setVisible(true);
    }
}
