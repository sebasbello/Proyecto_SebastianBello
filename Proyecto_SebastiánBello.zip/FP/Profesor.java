import java.util.ArrayList;

public class Profesor extends Persona{
  ArrayList<Estudiante> estudiantes;
  String matri;
  String ingreso;

    // Constructor por defecto.
    public Profesor(){

    }

    // Constructor.
    public Profesor(String nombre, int edad, String _matri, String _ingreso, ArrayList<Estudiante> _estudiantes){
      super(nombre, edad);
      this.matri = _matri;
      this.ingreso = _ingreso;
      this.estudiantes = _estudiantes;
    }

    public Profesor(String _ingreso, String _matri){
      this.ingreso = _ingreso;
      this.matri = _matri;
    }

    // Setters.
    public void setMatri(String _matri){
      this.matri = _matri;
    }

    public void setIngreso(String _ingreso){
      this.ingreso = _ingreso;
    }

    public void setEstudiantes(ArrayList<Estudiante> _estudiantes){
      this.estudiantes = _estudiantes;
    }

    // Getters.
    public String getMatri(){
      return matri;
    }

    public String getIngreso(){
      return ingreso;
    }

    public ArrayList<Estudiante>getEstudiante(){
      return estudiantes;
    }

    public String toString(){
      return "Nombre: " + super.getNombre() + " Ingreso: " + this.getIngreso() + " Matricula: " + this.getMatri();
    }
}
