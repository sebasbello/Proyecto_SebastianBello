import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class GestionBoton implements ActionListener{
  Ventana v;

    public GestionBoton(Ventana _ventana){
      v = _ventana;
    }

    public void actionPerformed(ActionEvent e){
      String usuario = v.jt.getText();
      char c[] = v.jp.getPassword();
      String clave = String.valueOf(c);

      if(usuario.equals("D") && clave.equals("UV")){
        MenuDirector md = new MenuDirector("Universidad Veracruzana - Director");
        v.dispose();
      }else{
        if(usuario.equals("A") && clave.equals("UV1")){
          MenuAdministrador ma = new MenuAdministrador("Universidad Veracruzana - Administrador");
          v.dispose();
        }else{
          if(usuario.equals("P") && clave.equals("UV2")){
            MenuProfesor mp = new MenuProfesor("Universidad Veracruzana - Profesor");
            v.dispose();
          }else{
            JOptionPane.showMessageDialog(v,"Datos no validos.");
        }
      }
    }
  }
}
