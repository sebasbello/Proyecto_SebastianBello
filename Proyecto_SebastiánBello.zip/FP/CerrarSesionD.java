public class CerrarSesionD implements java.awt.event.ActionListener{
  MenuDirector md;

    public CerrarSesionD(MenuDirector _md){
      md = _md;
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {
      try{
        Ventana v = new Ventana("Universidad Veracruzana");
          md.dispose();
       }catch(java.lang.NullPointerException z){
         System.out.println(z);
       }
     }
}
