import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.io.Writer;
import java.io.Reader;
import java.io.FileReader;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;

public class VentanaProfesor extends JFrame{
  // Componentes.
  JFrame f;
  ImageIcon ii;
  JMenuBar b;
  JMenu i,e,v;
  JMenuItem s,cs,p,a,adm;
  JTextField nombre, matricula,ing,posicion;
  JLabel no,ma,ed,pos;
  JButton regis,eli,cam;
  ArrayList<Profesor> profesor = new ArrayList<>();
  VentanaProfesor vp;
  int indice=0;
  Calendar cal = new GregorianCalendar();

    public VentanaProfesor(String _titulo){
      super(_titulo);
      // Definir la posición y la dimensión de la ventana.
      this.setBounds(50,50,600,600);
      this.setLayout(null);
      this.getContentPane().setBackground(Color.WHITE);

      // Logo.
      ii = new ImageIcon("imagen/logo.png");
      this.setIconImage(ii.getImage());

      // JMenuBar.
      b = new JMenuBar();

      // JMenu
      i = new JMenu("Inicio");
      b.add(i);

      e = new JMenu("Editar");
      b.add(e);

      adm = new JMenuItem("Administrador");
      e.add(adm);
      TransicionA ta = new TransicionA(this);
      adm.addActionListener(ta);

      v = new JMenu("Ver");
      b.add(v);

      // JMenuItem - Inicio
      cs = new JMenuItem("Cerrar sesion");
      i.add(cs);
      CerrarSesionP cse = new CerrarSesionP(this);
      cs.addActionListener(cse);

      s = new JMenuItem("Salir");
      i.add(s);
      s.addActionListener(
        new ActionListener(){
          public void actionPerformed(ActionEvent e){
            System.exit(0);
          }
        }
      );
      setJMenuBar(b);

      // JTextField.
      nombre = new JTextField("",30);
      nombre.setBounds(150,120,100,30);
      this.add(nombre);

      matricula = new JTextField("",30);
      matricula.setBounds(150,150,100,30);
      this.add(matricula);

      ing = new JTextField("",30);
      ing.setBounds(150,180,100,30);
      this.add(ing);

      posicion = new JTextField("",30);
      posicion.setBounds(480,150,60,30);
      posicion.setHorizontalAlignment(0);
      this.add(posicion);

      // JLabel.
      no = new JLabel("Nombre");
      no.setBounds(60,120,80,30);
      this.add(no);

      ma = new JLabel("Matricula");
      ma.setBounds(60,150,80,30);
      this.add(ma);

      ed = new JLabel("Ingreso");
      ed.setBounds(60,180,80,30);
      this.add(ed);

      pos = new JLabel("Posicion");
      pos.setBounds(420,150,60,30);
      pos.setHorizontalAlignment(0);
      this.add(pos);

      // Botón Agregar.
      regis = new JButton("Registrar");
      regis.setBounds(300,120,120,30);
      regis.setHorizontalAlignment(0);
      this.add(regis);
      regis.addActionListener(
        new ActionListener(){
          public void actionPerformed(ActionEvent e){
            try{
              Persona pr = new Profesor();
              if((matricula.getText().length()==8) && (ing.getText().replace("/","/").length()==10)){
                pr.setNombre(nombre.getText());
                ((Profesor)pr).setMatri(matricula.getText());
                ((Profesor)pr).setIngreso(ing.getText());
                profesor.add(((Profesor)pr));
              }else{
                throw new LimStringException("LimStringException");
              }

              File w = new File("Registro profesor.txt");
              if(!w.exists()){
                w.createNewFile();
                FileWriter fw = new FileWriter(w,true);
                PrintWriter pw = new PrintWriter(fw);
                pw.println("Actualizacion: " + cal.getTime());
                pw.println("\tDatos:");
                pw.println("\t"+profesor);
                pw.close();
                fw.close();
                nombre.setText("");
                matricula.setText("");
                ing.setText("");
                JOptionPane.showMessageDialog(vp, new JLabel("Agregado", JLabel.CENTER));
              }else{
                w.createNewFile();
                FileWriter fw = new FileWriter(w,true);
                PrintWriter pw = new PrintWriter(fw);
                pw.println("Actualizacion: " + cal.getTime());
                pw.println("\tDatos:");
                pw.println("\t"+profesor);
                pw.close();
                fw.close();
                nombre.setText("");
                matricula.setText("");
                ing.setText("");
                JOptionPane.showMessageDialog(vp, new JLabel("Agregado", JLabel.CENTER));
              }
            }catch(java.io.IOException a){
              System.out.println(a);
            }catch(java.lang.IndexOutOfBoundsException a){
              JOptionPane.showMessageDialog(vp, new JLabel("Limite rebasado", JLabel.CENTER));
            }catch(LimStringException a){
              JOptionPane.showMessageDialog(vp, new JLabel("Datos incorrectos", JLabel.CENTER));
            }
          }
        }
      );

      // Botón Cambio.
      cam = new JButton("Cambiar");
      cam.setBounds(300,150,120,30);
      cam.setHorizontalAlignment(0);
      this.add(cam);
      cam.addActionListener(
        new ActionListener(){
          public void actionPerformed(ActionEvent e){
            try{
              if(((posicion.getText()) != "") && (Integer.parseInt(posicion.getText())<profesor.size())){
                indice = Integer.parseInt(posicion.getText());
              }

              Persona pr = new Profesor();
              if((matricula.getText().length()==8) && (ing.getText().replace("/","/").length()==10)){
                pr.setNombre(nombre.getText());
                ((Profesor)pr).setMatri(matricula.getText());
                ((Profesor)pr).setIngreso(ing.getText());
                profesor.set(indice,((Profesor)pr));
              }else{
                throw new LimStringException("LimStringException");
              }

              File w = new File("Registro profesor.txt");
              if(!w.exists()){
                w.createNewFile();
                FileWriter fw = new FileWriter(w,true);
                PrintWriter pw = new PrintWriter(fw);
                pw.println("Actualizacion: " + cal.getTime());
                pw.println("\tDatos:");
                pw.println("\t"+profesor);
                pw.close();
                fw.close();
                nombre.setText("");
                matricula.setText("");
                ing.setText("");
                posicion.setText("");
                JOptionPane.showMessageDialog(vp, new JLabel("Cambiado", JLabel.CENTER));
              }else{
                w.createNewFile();
                FileWriter fw = new FileWriter(w,true);
                PrintWriter pw = new PrintWriter(fw);
                pw.println("Actualizacion: " + cal.getTime());
                pw.println("\tDatos:");
                pw.println("\t"+profesor);
                pw.close();
                fw.close();
                nombre.setText("");
                matricula.setText("");
                ing.setText("");
                posicion.setText("");
                JOptionPane.showMessageDialog(vp, new JLabel("Cambiado", JLabel.CENTER));
              }
            }catch(java.io.IOException a){
              System.out.println(a);
            }catch(java.lang.NumberFormatException a){
              JOptionPane.showMessageDialog(vp, new JLabel("Campo vacio", JLabel.CENTER));
            }catch(java.lang.IndexOutOfBoundsException a){
              JOptionPane.showMessageDialog(vp, new JLabel("Limite rebasado", JLabel.CENTER));
            }catch(LimStringException a){
              JOptionPane.showMessageDialog(vp, new JLabel("Datos incorrectos", JLabel.CENTER));
            }
          }
        }
      );

      // Botón Eliminar.
      eli = new JButton("Eliminar");
      eli.setBounds(300,180,120,30);
      eli.setHorizontalAlignment(0);
      this.add(eli);
      eli.addActionListener(
        new ActionListener(){
          public void actionPerformed(ActionEvent e){
            try{
              if(((posicion.getText()) != "") && (Integer.parseInt(posicion.getText())<profesor.size())){
                indice = Integer.parseInt(posicion.getText());
              }

              profesor.remove(indice);

              File w = new File("Registro profesor.txt");
              if(!w.exists()){
                w.createNewFile();
                FileWriter fw = new FileWriter(w,true);
                PrintWriter pw = new PrintWriter(fw);
                pw.println("Actualizacion: " + cal.getTime());
                pw.println("\tDatos:");
                pw.println("\t"+profesor);
                pw.close();
                fw.close();
                matricula.setText("");
                ing.setText("");
                posicion.setText("");
                JOptionPane.showMessageDialog(vp, new JLabel("Eliminado", JLabel.CENTER));
              }else{
                w.createNewFile();
                FileWriter fw = new FileWriter(w,true);
                PrintWriter pw = new PrintWriter(fw);
                pw.println("Actualizacion: " + cal.getTime());
                pw.println("\tDatos:");
                pw.println("\t"+profesor);
                pw.close();
                fw.close();
                matricula.setText("");
                ing.setText("");
                posicion.setText("");
                JOptionPane.showMessageDialog(vp, new JLabel("Eliminado", JLabel.CENTER));
              }
            }catch(java.io.IOException a){
              System.out.println(a);
            }catch(java.lang.NumberFormatException a){
              JOptionPane.showMessageDialog(vp, new JLabel("Campo vacio", JLabel.CENTER));
            }catch(java.lang.IndexOutOfBoundsException a){
              JOptionPane.showMessageDialog(vp, new JLabel("Limite rebasado", JLabel.CENTER));
            }
          }
        }
      );

      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.setVisible(true);
    }
}
