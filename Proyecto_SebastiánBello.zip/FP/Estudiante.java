import java.util.ArrayList;
public class Estudiante extends Persona{
  ArrayList<Materia> materias;
  String matri;
  String ingreso;

    // Constructor por defecto.
    public Estudiante(){

    }

    // Constructor.
    public Estudiante(String nombre, int edad, String _matri, String _ingreso, ArrayList<Materia> _materias){
      super(nombre, edad);
      this.matri = _matri;
      this.ingreso = _ingreso;
      this.materias = _materias;
    }

    // Setters.
    public void setMatri(String _matri){
      this.matri = _matri;
    }

    public void setIngreso(String _ingreso){
      this.ingreso = _ingreso;
    }

    public void setMaterias(ArrayList<Materia> _materias){
      this.materias = _materias;
    }

    // Getters.
    public String getMatri(){
      return matri;
    }

    public String getIngreso(){
      return ingreso;
    }

    public ArrayList<Materia> getMaterias(){
      return materias;
    }

    public String toString(){
      return "Ingreso: " + this.getIngreso() + " Matricula: " + this.getMatri() + "Clase: " + this.getMaterias();
    }
}
