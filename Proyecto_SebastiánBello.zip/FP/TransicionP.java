public class TransicionP implements java.awt.event.ActionListener{
  VentanaAdministrador md;

    public TransicionP(VentanaAdministrador _md){
      md = _md;
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {
      try{
        VentanaProfesor v = new VentanaProfesor("Universidad Veracruzana - Profesor");
          md.dispose();
       }catch(java.lang.NullPointerException z){
         System.out.println(z);
       }
     }
}
