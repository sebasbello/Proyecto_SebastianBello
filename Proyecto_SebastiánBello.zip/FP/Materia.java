public class Materia{
  String clase, profesor;
  double nota;

  // Constructor por defecto.
  public Materia(){

  }

  // Constructor.
  public Materia(String _clase, double _nota, String _profesor){
    this.profesor = _profesor;
    this.clase = _clase;
    this.nota = _nota;
  }

  // Setters.
  public void setProfesor(String _profesor){
    this.profesor = _profesor;
  }

  public void setClase(String _clase){
    this.clase = _clase;
  }

  public void setNota(double _nota){
    this.nota = _nota;
  }

  // Getters.
  public String getProfesor(){
    return profesor;
  }

  public String getClase(){
    return clase;
  }

  public double getNota(){
    return nota;
  }

  public String toString(){
    return "Clase: " + this.getClase() + " Calificacion: " + this.getNota() + " Profesor: " + this.getProfesor();
  }
}
