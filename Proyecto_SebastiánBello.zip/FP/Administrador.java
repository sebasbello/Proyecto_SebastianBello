import java.util.ArrayList;

public class Administrador extends Persona{
  ArrayList<Estudiante> estudiantes;
  String matri;
  String ingreso;

    // Constructor por defecto.
    public Administrador(){

    }

    // Constructor.
    public Administrador(String nombre, int edad, String _matri, String _ingreso, ArrayList<Estudiante> _estudiantes){
      super(nombre, edad);
      this.matri = _matri;
      this.ingreso = _ingreso;
      this.estudiantes = _estudiantes;
    }

    public Administrador(String _ingreso, String _matri){
      this.matri = _matri;
      this.ingreso = _ingreso;
    }

    // Setters.
    public void setMatri(String _matri){
      this.matri = _matri;
    }

    public void setIngreso(String _ingreso){
      this.ingreso = _ingreso;
    }

    public void setEstudiantes(ArrayList<Estudiante> _estudiantes){
      this.estudiantes = _estudiantes;
    }

    // Getters.
    public String getMatri(){
      return matri;
    }

    public String getIngreso(){
      return ingreso;
    }

    public ArrayList<Estudiante>getEstudiante(){
      return estudiantes;
    }

    public String toString(){
      return "Nombre: " + super.getNombre() + " Matricula: " + this.getMatri();
    }
}
